<?php
declare(strict_types=1);

return [
	'app_name' => 'Payroll',
	'from_email' => 'no-reply@example.com',
	'from_name' => 'Payroll System',
	'geofence_default_radius_m' => 200,
];

