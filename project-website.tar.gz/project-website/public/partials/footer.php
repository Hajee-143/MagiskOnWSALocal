<footer class="border-top mt-5 py-4">
	<div class="container text-center small text-muted">
		&copy; <span id="year"></span> Payroll. All rights reserved.
	</div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="/assets/js/main.js"></script>
</body>
</html>
