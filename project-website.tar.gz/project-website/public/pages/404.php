<main class="container py-5">
	<h1 class="h4">Page not found</h1>
	<p class="text-muted">The page you requested does not exist.</p>
	<a href="/index.php?page=login" class="btn btn-primary">Go to Login</a>
</main>
